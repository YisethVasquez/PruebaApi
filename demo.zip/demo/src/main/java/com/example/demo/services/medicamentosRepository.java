package com.example.demo.services;

import java.util.ArrayList;
import java.util.Optional;

import com.example.demo.models.medicamentosModels;
import com.example.demo.repositories.MedicamentosRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class medicamentoServices {
    @Autowired
    MedicamentosRepository MedicamentosRepository;
    
     public ArrayList<medicamentosModels> obtenerId_cita(){
        return (ArrayList<medicamentosModels>) MedicamentosRepository.findAll();
    }

    public medicamentosModels guardarId_cita(medicamentosModels id_cita){
        return MedicamentosRepository.save(id_cita);
    }

      public medicamentosModels guardarNmo_lote(medicamentosModels nmo_lote){
        return MedicamentosRepository.save(nmo_lote);
    }

    public Optional<medicamentosModels> obtenerPorId(Long id){
        return MedicamentosRepository.findById(id);
    }

    public boolean eliminarPaciente(Long id) {
        try{
            medicamentosModels.deleteById(id);
            return true;
        }catch(Exception err){
            return false;
        }
    }
