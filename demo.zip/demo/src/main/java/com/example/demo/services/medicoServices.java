package com.example.demo.services;

import java.util.ArrayList;
import java.util.Optional;

import com.example.demo.models.MedicoModels;
import com.example.demo.repositories.MedicoRepósitory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class medicoServices {
    @Autowired
    MedicoRepósitory MedicoRepósitory;
    
    public ArrayList<MedicoModels> obtenernmo_Licencia(){
        return (ArrayList<MedicoModelsodels>) MedicoRepósitoryRepository.findAll();
    }

    public MedicoModels guardarnmo_Licencia(MedicoModels nmo_Licencia){
        return MedicoRepósitory.save(nmo_Licencia);
    }

    public Optional<MedicoModels> obtenerPorId(Long id){
        return MedicoRepository.findById(id);
    }


    public ArrayList<MedicoModels>  obtenerPorNmo_Licencia(Integer nmo_Licencia) {
        return MedicoRepository.findByPrioridad(nmo_Licencia);
    }

    public boolean eliminarPaciente(Long id) {
        try{
            MedicoRepository.deleteById(id);
            return true;
        }catch(Exception err){
            return false;
        }
    }


    
}