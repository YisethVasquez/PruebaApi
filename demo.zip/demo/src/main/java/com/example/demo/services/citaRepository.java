package com.example.demo.services;

import java.util.ArrayList;
import java.util.Optional;

import com.example.demo.models.citaModels;
import com.example.demo.repositories.citaRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class citaServices {
    @Autowired
    citaRepository citaRepository;
    
     public ArrayList<citaModels> obtenerId_paciente(){
        return (ArrayList<citaModels>) citaRepository.findAll();
    }

    public citaModels guardarId_paciente(citaModels id_paciente){
        return citaRepository.save(id_paciente);
    }

      public citaModels guardarId_medico(citaModels id_medico){
        return citaRepository.save(id_medico);
    }

    public Optional<citaModels> obtenerPorId(Long id){
        return citaRepository.findById(id);
    }

    public boolean eliminarPaciente(Long id) {
        try{
            citaModels.deleteById(id);
            return true;
        }catch(Exception err){
            return false;
        }
    }
