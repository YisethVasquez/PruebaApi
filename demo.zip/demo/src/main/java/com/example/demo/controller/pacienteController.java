package com.example.demo.controllers;

import java.util.ArrayList;
import java.util.Optional;

import com.example.demo.models.pacienteModels;
import com.example.demo.services.pacienteServices;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping("/paciente")
public class PacienteController {
    @Autowired
    pacienteServices pacienteServices;

    @GetMapping()
    public ArrayList<pacienteModels> obtenerPacientes(){
        return pacienteServices.obtenerPacientes();
    }

    @PostMapping()
    public pacienteModels guardarUsuarguardarnmo_identificacionio(@RequestBody paciente nmo_identificacion){
        return this.pacienteServices.guardarnmo_identificacion(nmo_identificacion);
    }

    @GetMapping( path = "/{id}")
    public Optional<pacienteModels> obtenerUsuarioPorId(@PathVariable("id") Long id) {
        return this.pacienteServices.obtenerPorId(id);
    }

    @GetMapping("/query")
    public ArrayList<pacienteModels> obtenerPorId(@RequestParam("nmo_identificacion") Integer nmo_identificacion){
        return this.pacienteServices.obtenerPorId(nmo_identificacion);
    }

    @DeleteMapping( path = "/{id}")
    public String eliminarPorId(@PathVariable("id") Long id){
        boolean ok = this.pacienteServices.eliminarPaciente(id);
        if (ok){
            return "Se eliminó el usuario con id " + id;
        }else{
            return "No pudo eliminar el usuario con id" + id;
        }
    }

}