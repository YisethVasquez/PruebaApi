packege com.explem.demo.models;

import javax.persistence.*;


@Entity
@Table(name = "paciente")
public class pacienteModels{


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(unique = true, nullable = false)
privete Long id;


privete Long id_cita;
privete Long nmo_lote;
privete string nombre;
 


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }


        public Long getId_cita() {
        return id_cita;
    }

    public void setId_cita(Long id_cita) {
        this.id_cita = id_cita;
    }

        public Long getNmo_lote() {
        return nmo_lote;
    }

    public void setNmo_lote(Long nmo_lote) {
        this.nmo_lote = nmo_lote;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

}