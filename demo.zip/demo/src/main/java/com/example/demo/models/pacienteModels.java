packege com.explem.demo.models;

import javax.persistence.*;


@Entity
@Table(name = "paciente")
public class pacienteModels{


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(unique = true, nullable = false)
privete Long id;


privete integer nmo_identificacion;
privete string nombre;
privete string apellido;
privete integer edad;
privete string genero; 


 public void setnmo_identificacion(Integer nmo_identificacion){
        this.nmo_identificacion = nmo_identificacion;
    }

    public Integer nmo_identificacion(){
        return nmo_identificacion;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

     public String getApellido() {
        return napellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

     public void setEdad(Integer edad){
        this.edad = edad;
    }

    public Integer edad(){
        return edad;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }
    

}