package com.example.demo.services;

import java.util.ArrayList;
import java.util.Optional;

import com.example.demo.models.pacienteModels;
import com.example.demo.repositories.pacienteRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class pacienteServices {
    @Autowired
    pacienteRepository pacienteRepository;
    
    public ArrayList<pacienteModels> obtenernmo_identificacion(){
        return (ArrayList<pacienteModels>) pacienteRepository.findAll();
    }

    public pacienteModels guardarnmo_identificacion(pacienteModels nmo_identificacion){
        return pacienteRepository.save(nmo_identificacion);
    }

    public Optional<pacienteModels> obtenerPorId(Long id){
        return pacienteRepository.findById(id);
    }


    public ArrayList<pacienteModels>  obtenerPorNmo_identificacion(Integer nmo_identificacion) {
        return pacienteRepository.findByPrioridad(nmo_identificacion);
    }

    public boolean eliminarPaciente(Long id) {
        try{
            pacienteRepository.deleteById(id);
            return true;
        }catch(Exception err){
            return false;
        }
    }


    
}