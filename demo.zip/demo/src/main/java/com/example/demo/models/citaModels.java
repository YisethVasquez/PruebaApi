packege com.explem.demo.models;

import javax.persistence.*;


@Entity
@Table(name = "paciente")
public class pacienteModels{


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(unique = true, nullable = false)
privete Long id;


privete Long id_paciente;
privete Long id_medico;
privete datetime fecha;
privete datetime hora; 


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

     public Long getId_paciente() {
        return id_paciente;
    }

    public void setId_paciente(Long id_paciente) {
        this.id_paciente = id_paciente;
    }


     public Long getId_medico() {
        return id_medico;
    }

    public void setId_medico(Long id_medico) {
        this.id_medico = id_medico;
    }



    public Datetime getFecha() {
        return fecha;
    }

    public void setFecha(Datetime fecha) {
        this.fecha = fecha;
    }


    public Datetime getHora(){
        return hora;
    }

    public void setHora(Datetime hora){
        this.hora = fecha; 
    }

    

}