package com.example.demo.repositories;

import java.util.ArrayList;

import com.example.demo.models.citaModels;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface citasRepository extends CrudRepository<citaModels, Long> {
    public abstract ArrayList<citaModels> findById_paciente(Integer id_paciente);

}