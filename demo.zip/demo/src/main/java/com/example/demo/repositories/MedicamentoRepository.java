package com.example.demo.repositories;

import java.util.ArrayList;

import com.example.demo.models.medicamentoModels;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface MedicamentoRepository extends CrudRepository<medicamentoModels, Long> {
    public abstract ArrayList<medicamentoModels> findById_cita(Integer id_cita);

}