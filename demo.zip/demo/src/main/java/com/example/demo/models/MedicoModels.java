packege com.explem.demo.models;

import javax.persistence.*;


@Entity
@Table(name = "paciente")
public class pacienteModels{


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(unique = true, nullable = false)
privete Long id;


privete integer nmo_licencia;
privete string nombre;
privete string apellido;
privete string especialidad; 


 public void setnmo_licencia(Integer nmo_licencia){
        this.nmo_licencia = nmo_licencia;
    }

    public Integer nmo_licencia(){
        return nmo_licencia;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

     public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getEspecialidao() {
        return especialidad;
    }

    public void seeEspecialidad(String especialidad) {
        this.especialidad = especialidad;
    }
    

}