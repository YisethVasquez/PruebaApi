package com.example.demo.repositories;

import java.util.ArrayList;

import com.example.demo.models.MedicoModels;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface MedicoRepository extends CrudRepository<MedicoModels, Long> {
    public abstract ArrayList<MedicoModels> findByNmo_Licencia(Integer nmo_licencia);

}