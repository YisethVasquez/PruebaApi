package com.example.demo.repositories;

import java.util.ArrayList;

import com.example.demo.models.pacienteModels;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface pacienteRepository extends CrudRepository<pacienteModels, Long> {
    public abstract ArrayList<pacienteModels> findByNmo_identificacion(Integer nmo_identificacion);

}